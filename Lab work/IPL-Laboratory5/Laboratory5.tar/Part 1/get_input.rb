# frozen_string_literal:true

require './main'

x = gets.to_f
a = Calculate.new(x)
a.calc
a.prt
